import highlight from "@/assets/images/highlight.png";
import rankingGradient from "@/assets/images/rankingGradient.png";
import netback from "@/assets/images/netback.png";

export const images = {
  highlight,
  rankingGradient,
  netback,
};
